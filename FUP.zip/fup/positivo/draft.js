let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let int = parseInt(+input());

if (int >= 0){
  write("SIM")
} else {
  write("\n")
}