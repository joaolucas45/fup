let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let valorProd = +input();
let chute1 =  +input();
let chute2 =  +input();

let distancia1 = Math.abs(chute1 - valorProd); //abs calcula a diferença entre os dois numeros e retorna o valor positivo dessa diferença
let distancia2 = Math.abs(chute2 - valorProd);

if (distancia1 > distancia2){
  console.log("segundo")
} else if (distancia2 > distancia1){
  console.log("primeiro")
} else {
  console.log("empate")
}
