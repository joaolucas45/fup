let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let qtda = +input();
let qtdb = +input();
let qtdc = +input();

let pa = +input();
let pb = +input();
let pc = +input();

let dinheiro = +input();

custo = qtda * pa + qtdb * pb + qtdc * pc;

troco = dinheiro - custo;

console.log(troco.toFixed(2))