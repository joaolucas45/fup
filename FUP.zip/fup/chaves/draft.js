let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let num1 = +input();

if (num1 > 0){
  write("positivo")
} else if (num1 < 0){
  write("negativo")
} else {
  write("nulo")
}