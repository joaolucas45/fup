let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let a = +input(); // +input() -> converter para numero 
let b = +input(); 
let c = +input();
let resposta = a + b + c;
console.log(resposta)