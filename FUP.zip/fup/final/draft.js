let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let nota1 = +input();
let nota2 = +input();
let notaF = +input();
let media = (nota1+nota2)/2;
let mediaF = (media + notaF)/2
if (media > 7){
  write("aprovado")
} else if (media < 4){
  write("reprovado")
}
else if (7 > media && media > 4 && mediaF >= 5){
  write("aprovado na final")
} else if (7 > media && media > 4 && mediaF < 5){
  write("reprovado na final")
}