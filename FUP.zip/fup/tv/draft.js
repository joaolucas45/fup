//let __lines = require("fs").readFileSync(0).toString().split("\n");
//let input = () => __lines.length === 0 ? "" : __lines.shift();
//let write = (text, end = "\n") => process.stdout.write("" + text + end);

let i = 0;
while (true) {
  console.log(i);
  i += 1;
  if (1 >= 10){
    break;
  }
}
