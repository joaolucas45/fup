# L0 - É 3 @ou 5

- Veja a versão online: [aqui.](https://github.com/qxcodefup/arcade/blob/master/base/ou/Readme.md)
- Para programar na sua máquina (local/virtual) use:
  - `tko down fup ou`
- Se não tem o `tko`, instale pelo [LINK](https://github.com/senapk/tko#tko).

---

![Imagem eh o número 3](https://raw.githubusercontent.com/qxcodefup/arcade/master/base/ou/cover.jpg)

## Ação

Implemente um programa que recebe um número inteiro e imprima SIM caso ele seja o
número 3 ou o número 5.

### Entrada

- Um inteiro

### Saída

- "SIM" se o número for igual a 3, ou 5, caso contrário, "NAO"

## Exemplos

```txt
>>>>>>>> 0
3
========
SIM
<<<<<<<<

>>>>>>>> 1
12
========
NAO
<<<<<<<<

>>>>>>>> 2
-3
========
NAO
<<<<<<<<

>>>>>>>> 3
-7
========
NAO
<<<<<<<<

>>>>>>>> 4
5
========
SIM
<<<<<<<<
```
