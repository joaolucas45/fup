let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let l1 = +input();
let l2 = +input();
let l3 = +input();

if (l1 >= l2 + l3 || l2 >= l1 + l3 || l3 >= l1 + l2){
  write("False")
} else{
  write("True")
}