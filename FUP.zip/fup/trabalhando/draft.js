let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let dia = +input();
let hora = parseInt(+input());

if (dia >= 2 && dia < 7 && hora >= 8 && hora <= 11 || dia >= 2 && dia < 7 && hora >= 14 && hora <= 17){
  write("SIM")
} else if (dia == 7 && hora >= 8 && hora <= 11){
  write("SIM")
} else{
  write("NAO")
}