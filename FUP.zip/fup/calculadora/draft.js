let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let num1 = +input();
let num2 = +input();
let op = input();

if (op == "/"){
  write(parseInt(num1/num2));
} else if (op == "+"){
  write(num1+num2)
} else if (op == "-"){
  write(num1-num2)
} else {
  write(num1*num2)
}