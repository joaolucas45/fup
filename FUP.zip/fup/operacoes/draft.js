let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let a = +input();
let b = +input();

let resS = a + b;
let resSub = a - b;
let resM = a * b;
let resD = a / b;
let resR = a % b;

console.log(resS + '\n' + resSub + '\n' + resM + '\n' + parseFloat(resD).toFixed(2) + '\n' + resR)
