let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let hora = +input();
let minuto = +input();
let dia = +input();
let mes = +input();
let ano = +input();

console.log (hora.toString().padStart(2, 0) +":"+ minuto.toString().padStart(2, 0) + " " + dia.toString().padStart(2,0) + "/" + mes.toString().padStart(2,0) + "/" + ano.toString().slice(-2))