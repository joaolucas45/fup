let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let char = input();
let num = +input();

if (char == "c"){
  let numF = Math.ceil(num);
  console.log(numF);
} else if (char == "r"){
  let numF = Math.round(num);
  console.log(numF);
} else if (char == "f"){
  let numF = Math.floor(num);
  console.log(numF);
}
