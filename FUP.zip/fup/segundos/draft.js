let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

let total = +input();

let hora = (total/3600);
let minuto = ((total % 3600)/60);
let segundo = (total % 60);

console.log(parseInt(hora) + ":" + parseInt(minuto) + ":" + parseInt(segundo))
