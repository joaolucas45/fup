let __lines = require("fs").readFileSync(0).toString().split("\n");
let input = () => __lines.length === 0 ? "" : __lines.shift();
let write = (text, end="\n") => process.stdout.write("" + text + end);

function distanciapontos(x1, y1, x2, y2){
let deltax = (x2-x1) 
let deltay = (y2-y1);

return Math.sqrt(deltax * deltax + deltay * deltay);
}

let x1 = +input()
let y1 = +input()
let x2 = +input()
let y2 = +input()

let dab = distanciapontos(x1,y1,x2,y2);

console.log(parsefdab)